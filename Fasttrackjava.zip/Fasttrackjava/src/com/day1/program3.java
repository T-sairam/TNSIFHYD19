package com.day1;

public class program3 {
	public static void main(String[] args) {
		
		int i,fact=1;
		int number =5;
		for (i=1;i<=number;i++)
		{
			if(number==1)
			{
				fact=0;
			}
			else
			fact=fact*i;
			}
	System.out.println("factorial of number is" + fact);
	}

}
