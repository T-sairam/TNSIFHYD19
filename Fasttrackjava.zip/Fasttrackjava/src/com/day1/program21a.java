package com.day1;

public class program21a {
	
	private void display()

	{

	System.out.println("TNS Sessions");

	}

	}


