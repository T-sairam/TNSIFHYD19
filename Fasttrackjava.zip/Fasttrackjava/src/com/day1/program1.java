package com.day1;

public class program1 {

	public static void main(String[] args) {
		
	   System.out.println("hello world");
	}

}
