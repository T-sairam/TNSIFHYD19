package com.day1;

import java.util.Scanner;

public class program11 {

	public static void main(String[] args) {
		int a,b,sum;
		float avg;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter first number");
		a=sc.nextInt();
		System.out.println("enter second number3");
		b=sc.nextInt();
		sum= a+b;
		avg=sum/2f;
		System.out.println("average is "+ avg);
		
		
	}

}
