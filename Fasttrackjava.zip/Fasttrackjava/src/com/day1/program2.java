package com.day1;

import java.util.Scanner;

public class program2 {

	public static void main(String[] args) {
		int a;
		Scanner  sc = new Scanner(System.in);
		
		System.out.println("enter a number");
		 a= sc.nextInt();
		 if (a%2==0)
		 {
			 System.out.println("a is a even number");
		 }
		 else
		 {
			 System.out.println("a is a odd number");
		 }
		 
		}

}
