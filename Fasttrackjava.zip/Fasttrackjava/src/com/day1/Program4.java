package com.day1;

import java.util.Scanner;

public class Program4 {

	public static void main(String[] args) {
	int a,i;
	int count=0;
	Scanner sc = new Scanner(System.in);
	a=sc.nextInt();
	
	 for (i=1;i<=a;i++)
	 {
		 if (a%i==0)
		 {
			 count=count++;
		 }
	 }
	 if(count>2)
	 {
System.out.println(" this is not a prime number");
	}
	 else
	 {
		 System.out.println("this a prime");
	 }
}
}
