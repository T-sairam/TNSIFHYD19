package com.day1;

public class program21b {

	public static void main(String[] args) {
		program21a obj = new program21a();
		 
		obj. display();
	}

}
