package com.day1;

public class NormalClass {
	
	int a =10; //instance variable
	static int b=20; //static variable
	
	
	//instance method
	String display() {
		return "Hello Display";
	}
	
	//static method
	public static String display1() {
		return "Hello static display";
	}

}
