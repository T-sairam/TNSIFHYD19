package com.day1pack1;
class MyClass1
{
void display()
{
System.out.println("Hello World!");
}
}
