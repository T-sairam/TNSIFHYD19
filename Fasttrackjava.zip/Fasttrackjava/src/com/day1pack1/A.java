package com.day1pack1;



public class A

{

public void display()

{

System.out.println("TNS Sessions");

}

}