package com.day1pack1;

public class ClassA {
	
	protected void display()

	{

	System.out.println("TNS Sessions");

	}

	}


