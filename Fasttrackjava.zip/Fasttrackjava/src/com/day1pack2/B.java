package com.day1pack2;

import com.day1pack1.*;

class B

{

public static void main(String[] args)

{

A obj = new A();

obj.display();

}

}