package com.day1pack2;

import com.day1pack1.*;

public class ClassB extends ClassA

{

public static void main(String[] args)

{

ClassB obj = new ClassB();

obj.display();

}

}
