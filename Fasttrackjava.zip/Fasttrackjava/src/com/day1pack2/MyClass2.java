package com.day1pack2;

import day1pack1.*;

//This class is having default access modifier

class MyClass2

{

public static void main(String args[])

{

//accessing class MyClass1 from package p1

MyClass1 obj = new MyClass1();

obj.display();

}

}
